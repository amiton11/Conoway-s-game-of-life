﻿namespace GameOfLife
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GamePanel = new System.Windows.Forms.Panel();
            this.Clear_btn = new System.Windows.Forms.Button();
            this.Game_btn = new System.Windows.Forms.Button();
            this.Action_timer = new System.Windows.Forms.Timer(this.components);
            this.Random_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GamePanel
            // 
            this.GamePanel.Location = new System.Drawing.Point(12, 12);
            this.GamePanel.Name = "GamePanel";
            this.GamePanel.Size = new System.Drawing.Size(500, 500);
            this.GamePanel.TabIndex = 0;
            // 
            // Clear_btn
            // 
            this.Clear_btn.Location = new System.Drawing.Point(87, 518);
            this.Clear_btn.Name = "Clear_btn";
            this.Clear_btn.Size = new System.Drawing.Size(107, 23);
            this.Clear_btn.TabIndex = 0;
            this.Clear_btn.Text = "Clear Board";
            this.Clear_btn.UseVisualStyleBackColor = true;
            this.Clear_btn.Click += new System.EventHandler(this.Clear_btn_Click);
            // 
            // Game_btn
            // 
            this.Game_btn.Location = new System.Drawing.Point(200, 518);
            this.Game_btn.Name = "Game_btn";
            this.Game_btn.Size = new System.Drawing.Size(107, 23);
            this.Game_btn.TabIndex = 1;
            this.Game_btn.Text = "Play";
            this.Game_btn.UseVisualStyleBackColor = true;
            this.Game_btn.Click += new System.EventHandler(this.Game_btn_Click);
            // 
            // Action_timer
            // 
            this.Action_timer.Tick += new System.EventHandler(this.Action_timer_Tick);
            // 
            // Random_btn
            // 
            this.Random_btn.Location = new System.Drawing.Point(313, 518);
            this.Random_btn.Name = "Random_btn";
            this.Random_btn.Size = new System.Drawing.Size(107, 23);
            this.Random_btn.TabIndex = 2;
            this.Random_btn.Text = "Random Grid";
            this.Random_btn.UseVisualStyleBackColor = true;
            this.Random_btn.Click += new System.EventHandler(this.Random_btn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(524, 551);
            this.Controls.Add(this.Random_btn);
            this.Controls.Add(this.Game_btn);
            this.Controls.Add(this.Clear_btn);
            this.Controls.Add(this.GamePanel);
            this.Name = "MainForm";
            this.Text = "Game Of Life";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Button Clear_btn;
        private System.Windows.Forms.Button Game_btn;
        private System.Windows.Forms.Timer Action_timer;
        private System.Windows.Forms.Button Random_btn;
    }
}


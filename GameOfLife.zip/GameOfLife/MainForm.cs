﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace GameOfLife
{
    public partial class MainForm : Form
    {
        private const int BoardSize = 50;

        private BoardGame MyBoard;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            MyBoard = new BoardGame(BoardSize, GamePanel);
        }

        private void Game_btn_Click(object sender, EventArgs e)
        {
            Action_timer.Enabled = !Action_timer.Enabled;
            if (Game_btn.Text == "Play")
                Game_btn.Text = "Stop";
            else
                Game_btn.Text = "Play";
        }

        private void Clear_btn_Click(object sender, EventArgs e)
        {
            if (Action_timer.Enabled)
                Game_btn_Click(sender, e);
            MyBoard.ClearBoard();
        }

        private void Random_btn_Click(object sender, EventArgs e)
        {
            if (Action_timer.Enabled)
                Game_btn_Click(sender, e);
            MyBoard.RandomBoard();
        }
        
        private void Action_timer_Tick(object sender, EventArgs e)
        {
            MyBoard.PlayTurn();
        }
        
    }

    public class BoardGame : System.Collections.IEnumerable
    {

        // Fields
        private bool[,] cells;

        private Panel gamePanel;

        private Graphics panelGraphics;

        private int cellH, cellW;

        private static Random rand = new Random();

        private static SolidBrush blackBrush = new SolidBrush(Color.Black);
        private static SolidBrush greenBrush = new SolidBrush(Color.Green);

        // C'tors

        public BoardGame (int BoardSize, Panel GamePanel)
        {
            cells = new bool[BoardSize, BoardSize];
            cellH = GamePanel.Height / BoardSize;
            cellW = GamePanel.Width / BoardSize;
            gamePanel = GamePanel;
            panelGraphics = gamePanel.CreateGraphics();
            ClearBoard();
        }

        // Properties

        //public bool ButtonsState
        //{
        //    get 
        //    { 
        //    }
        //    set 
        //    {
        //    }
        //}

        public int BoardSize
        {
            get
            {
                return cells.GetLength(0);
            }
        }

        // indexers

        public bool this[int indY, int indX]
        {
            get
            {
                if (indY < 0)
                    indY = BoardSize + indY;
                if (indX < 0)
                    indX = BoardSize + indX;
                return cells[indY % BoardSize, indX % BoardSize];
            }
        }

        // Methods

        public void PlayTurn()
        {
            bool[,] NewStates = new bool[BoardSize, BoardSize];

            for (int i = 0; i < BoardSize * BoardSize; i++)
            {
                int X = i % BoardSize;
                int Y = i / BoardSize;
                NewStates[Y, X] = GetNewState(X, Y);
            }

            for (int i = 0; i < BoardSize * BoardSize; i++)
            {
                int X = i % BoardSize;
                int Y = i / BoardSize;
                cells[Y, X] = NewStates[Y, X];
            }

            PrintBoard();
        }

        public void ClearBoard()
        {
            for (int i = 0; i < BoardSize * BoardSize; i++)
            {
                int X = i % BoardSize;
                int Y = i / BoardSize;
                cells[Y, X] = false;
            }
            PrintBoard();
        }

        public void RandomBoard()
        {
            for (int i = 0; i < BoardSize * BoardSize; i++)
            {
                int X = i % BoardSize;
                int Y = i / BoardSize;
                cells[Y, X] = RandomBool();
            }
            PrintBoard();
        }

        private static bool RandomBool()
        {
            return rand.NextDouble() > 0.5;
        }

        private bool GetNewState(int X, int Y)
        {
            int Count = 0;
            for (int i = 0; i < 9; i++)
            {
                if (i == 4) 
                    continue;
                int relativeX = i % 3 - 1;
                int relativeY = i / 3 - 1;
                if (this[Y + relativeY, X + relativeX])
                    Count++;
            }
            if (Count == 2)
                return cells[Y, X];
            if (Count == 3)
                return true;
            return false;
        }

        private void PrintBoard()
        {
            for (int i = 0; i < BoardSize * BoardSize; i++)
            {
                int X = i % BoardSize;
                int Y = i / BoardSize;
                if (cells[Y, X])
                    panelGraphics.FillRectangle(greenBrush, X * cellW, Y * cellH, cellW, cellH);
                else
                    panelGraphics.FillRectangle(blackBrush, X * cellW, Y * cellH, cellW, cellH);
            }
        }

        #region IEnumerable Members

        public System.Collections.IEnumerator GetEnumerator()
        {
            return cells.GetEnumerator();
        }

        #endregion
    }
}
